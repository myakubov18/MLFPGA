# Please unzip mnist.zip file

Please unzip the mnist.zip file into this directory before running the code. 